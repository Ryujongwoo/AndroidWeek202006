1. 1개의 아이템을 표시할 XML을 만든다.  --- chunja1.xml
2. 1개의 데이터를 저장할 클래스를 만든다. --- Chunja1.java
3. 1개의 데이터를 안드로이드의 뷰로 만든다. --- ChunjaView1.java
4. 여러개 데이터를 가지는 어뎁터 클래스를 만든다. --- ChunjaAdapter1.java