package com.example.administrator.progressbartest;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements Runnable {

    TextView tv;
//  ProgressBar에 대한 작업을 하려면 Thread에서 Message를 만들어 Bundle에 저장한 후 Handler로 넘겨준다.
    ProgressBar progressBar;
    RatingBar ratingBar;
    SeekBar seekBar;

//  내부 클래스로 정의한 ProgressBar에 대한 UI를 갱신하는 Handler 객체를 선언한다.
    ProgressHandler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = findViewById(R.id.tv);
        progressBar = findViewById(R.id.progressBar);
        ratingBar = findViewById(R.id.ratingBar);
        seekBar = findViewById(R.id.seekBar);
//      Handler 객체를 선언하고 스레드를 실행한다.
        handler = new ProgressHandler();
        new Thread(this).start();

//      RatingBar가 변경될 때 마다 실행할 동작이 있으면 setOnRatingBarChangeListener()를 할당한다.
        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
                Toast.makeText(getApplicationContext(), "별점 : " + ratingBar.getRating(),
                        Toast.LENGTH_SHORT).show();
            }
        });
//      SeekBar가 변경될 때 마다 실행할 동작이 있으면 setOnSeekBarChangeListener()를 할당한다.
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
//          SeekBar가 움질일 때 마다 실행된다.
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                Toast.makeText(getApplicationContext(), "" + i, Toast.LENGTH_SHORT).show();
            }
//          SeekBar가 처음 터치될 때 실행된다.
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                Toast.makeText(getApplicationContext(), "SeekBar 터치 시작", Toast.LENGTH_SHORT).show();
            }
//          SeekBar에서 손가락이 떨어지면 실행된다.
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(getApplicationContext(), "SeekBar 터치 끝", Toast.LENGTH_SHORT).show();
            }
        });
    }

//  Handler 클래스를 상속받아 UI를 갱신하는 클래스를 만든다.
    class ProgressHandler extends Handler {
//      Handler를 통해서 넘어오는 데이터를 받아주는 handleMessage() 메소드를 override 한다.
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
//          Handler를 통해서 넘어오는 데이터를 받는다.
            int value = msg.getData().getInt("value");
//          Handler를 통해서 넘어온 데이터로 UI를 갱신한다.
            if(value < 100) {
                tv.setText("현재값 : " + value);
            } else {
                tv.setText("작업완료!!!");
            }
//          ProgressBar에 값을 넣어준다.
            progressBar.setProgress(value);
//          seekBar.setProgress(value);
        }
    }

    @Override
    public void run() {
        int value = 0;
        while(value < 100) {
            value++;
//          스레드에서 변경된 내용으로 UI를 갱신하도록 알린다.
//          Handler를 통해서 ProgressBar로 메시지를 전달할 Message 클래스 객체를 만든다.
            Message message = handler.obtainMessage();
//          ProgressBar로 전달할 데이터를 저장할 Bundle 클래스 객체를 만든다.
            Bundle bundle = new Bundle();
//          Bundle 객체에 ProgressBar로 전달할 데이터를 저장한다.
            bundle.putInt("value", value);
//          Bundle 객체에 저장된 값을 Message 객체에 넣어준다.
            message.setData(bundle);
//          Message를 Handler로 전달한다.
            handler.sendMessage(message);
            try { Thread.sleep(100); } catch (InterruptedException e) { e.printStackTrace(); }
        }
    }
}
